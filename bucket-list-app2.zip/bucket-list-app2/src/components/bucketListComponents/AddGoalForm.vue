<template>
  <v-sheet id="addGoalFormWrapper" class="ma-2 elevation-4">
    <app-button icon="mdi-close"
                tool-tip="Close"
                tool-tip-location="left"
                :button-action="closeForm">
    </app-button>
    <v-form>
      <v-text-field
        v-model="newBucketListItem.goalTitle"
        :counter="20"
        :rules="[v => !!v || 'Item is required']"
        label="Goal Title"
        required
      ></v-text-field>

      <v-text-field
        v-model="newBucketListItem.goalDescription"
        label="Description"
        :counter="100"
        required
      ></v-text-field>

      <v-checkbox
        v-model="newBucketListItem.isFavorite"
        label="Mark as Favorite?"
      ></v-checkbox>

      <div class="d-flex flex-column">
        <app-button button-text="Add Goal"
                    icon="mdi-plus"
                    :button-action="addGoal"
                    color="primary">
        </app-button>

        <app-button button-text="Start Over"
                    icon="mdi-refresh"
                    :button-action="clearNewItem"
                    color="error"
                    class="mt-3">
        </app-button>
      </div>
    </v-form>
  </v-sheet>
</template>

<script setup>
import AppButton from "@/components/appComponents/AppButton";
</script>

<script>
import BucketListItemModel from "@/Models/BucketListItemModel";

export default {
  name: "AddGoalForm",
  computed: {
    todaysDate() {
      let today = new Date();
      let dd = String(today.getDate()).padStart(2, '0');
      let mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
      let yyyy = today.getFullYear();

      return mm + '/' + dd + '/' + yyyy;
    }
  },
  props: {
    newBucketListItem: {
      type: BucketListItemModel,
      required: true,
    }
  },
  methods: {
    clearNewItem() {
      this.newBucketListItem = new BucketListItemModel(this.todaysDate, "", "", false, false);
    },
    addGoal(){
      console.log("calling add goal");
      this.$emit("add-goal", this.newBucketListItem);
    },
    closeForm(){
      console.log("emitting close");
      this.$emit("close-add-form");
    }
  }
}
</script>

<style>
  #addGoalFormWrapper{
    position: absolute;
    bottom: 2vh;
    right: 1.5vw;
    min-width: 350px;
    padding: 20px;
    border-radius: 10px;
  }
</style>
