<template>

  <div id="mainContainer" class="bg-brown-lighten-5">
    <v-sheet height="80vh" class="d-flex bg-brown-lighten-5">
      <div class="ma-5">
        <bucket-list-item v-for="bucketListItem in bucketListItems" :bucket-list-item="bucketListItem" class="mb-3"></bucket-list-item>
      </div>
    </v-sheet>
    <div id="addGoalButtonContainer">
      <app-button class="bg-primary rounded-circle d-block float-end"
                  icon="mdi-plus"
                  button-size="xxx-large"
                  tool-tip="Add a life goal!"
                  tool-tip-location="left"
                  :button-action="addGoal">
      </app-button>
      <add-goal-form :new-bucket-list-item="newBucketListItem"></add-goal-form>
    </div>
  </div>
</template>

<script setup>
import AppButton from "@/components/appComponents/AppButton";
import AddGoalForm from "@/components/bucketListComponents/AddGoalForm";
</script>

<script>
import BucketListItem from "@/components/bucketListComponents/BucketListItem";
import BucketListItemModel from "@/Models/BucketListItemModel";

export default {
  name: "BucketList",
  components: {BucketListItem},
  props: {
    bucketListItems: {
      type: Array,
    }
  },
  computed: {
    uncompletedBucketListItems() {
      return this.bucketListItems.filter((item) => item.goalCompleted === false);
    },
    completedBucketListItems() {
      return this.bucketListItems.filter((item) => item.goalCompleted === true);
    },
  },
  methods: {
    filterByCategory(category) {
      return this.bucketListItems.filter(item => item.categories.contains(category));
    },
    addGoal(bucketListItem){
      console.log("Adding Goal: " + bucketListItem.goalTitle);
      this.bucketListItems.push(bucketListItem);
    },
    editGoal(bucketListItem){
      console.log("Editing Goal");
    },
    favoriteGoal(bucketListItem){
      console.log("Favorite-ing Goal");
      if (!this.bucketListItems[bucketListItem].isFavorite) {
        this.bucketListItems[bucketListItem].isFavorite = true;
      } else {
        this.bucketListItems[bucketListItem].isFavorite = false;
      }
    },
    deleteGoal(bucketListItem){
      console.log("Deleting Goal");
      this.bucketListItems.splice(bucketListItem);
    },
    closeAddForm(){

    }
  },
  data() {
    return {
      newBucketListItem: new BucketListItemModel(this.todaysDate, "", "", false, false),
    }
  },
}
</script>

<style>
  #addGoalButtonContainer{
    position: absolute;
    right: 1vw;
    top: 79.5vh;
    margin-right: 5px;
  }
</style>
